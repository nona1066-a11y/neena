
DROP INDEX idx_user_preferences_user_id;
DROP INDEX idx_sound_sessions_user_id;
DROP INDEX idx_sleep_sessions_user_id;
DROP TABLE user_preferences;
DROP TABLE sound_sessions;
DROP TABLE sleep_sessions;
